#include "Cuenta.h"
#include<string>

using namespace std;

    Cuenta::Cuenta();

    void Cuenta::setNumCuenta(long numCuenta){
        if(numCuenta<1000000000 && numCuenta>99999999){
        numCuenta=numCuenta;
        }
    }

    long Cuenta::getNumCuenta(){
        return numCuenta;
    }

    string Cuenta::getTitular(){
        return titular;
    }

    void Cuenta::setTitular(string titularN) {
        titular = titularN;
    }

    float Cuenta::getSaldo() {
        return saldo;
    }

    void Cuenta::setSaldo(float saldoN) {
        saldo = saldoN;
    }

    void Cuenta::retiro(float saldo){
            int retiro=0;
            do{
                cout<<"Cuento desea retirar? "<<endl;
                cin>>retiro;
            }
            while(retiro>saldo);
            saldo=saldo-retiro;
            cout<<"Su saldo restante es: "<<saldo<<endl;
    }
    void Cuenta::deposito(float saldo){
        int suma=0;
        cout<<"Cuanto desea depositar? "<<endl;
        cin>>suma;
        saldo=saldo+suma;
        cout<<"Su saldo total es: "<<saldo<<endl;
    }

    void Cuenta::consulta(float saldo){
        cout<<"Su saldo es de: "<<saldo<<endl;
    }

    void Cuenta::consultaCuenta(float saldo, long numCuenta, string titular){
        cout<<titular<<"\n"<<numCuenta<<"\n"<<saldo<<endl;
    }

Cuenta::~Cuenta()
{
    //dtor
}
