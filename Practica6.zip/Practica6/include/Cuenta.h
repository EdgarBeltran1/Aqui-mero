#ifndef CUENTA_H
#define CUENTA_H
#include<string>
#include<iostream>

using namespace std;

class Cuenta
{
    private:
        long numCuenta;
        string titular;
        float saldo;

    public:
        Cuenta();

        virtual ~Cuenta();

        long getNumCuenta(){
        }
        void setNumCuenta(long) {
        }

        string getTitular() {

        }

        void setTitular(string) {
        }

        float getSaldo() {
        }

        void setSaldo(float) {
        }

        void retiro(float){
        }

        void deposito(float){
        }

        void consulta(float){
        }

        void consultaCuenta(float, long, string){
        }

    protected:

};

#endif // CUENTA_H
